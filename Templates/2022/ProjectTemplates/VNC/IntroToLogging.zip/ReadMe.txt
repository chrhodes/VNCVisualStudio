﻿$safeprojectname$

Notes for using this template
