﻿namespace $safeprojectname$
{
    public class Common
    {
        public const string PROJECT_NAME = "$safeprojectname$";
        public const string LOG_APPNAME = "$safeprojectname$";
    }
}
