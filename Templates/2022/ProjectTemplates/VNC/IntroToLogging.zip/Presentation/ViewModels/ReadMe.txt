﻿$safeprojectname$\Presentation\ViewModels\

Notes for using this template