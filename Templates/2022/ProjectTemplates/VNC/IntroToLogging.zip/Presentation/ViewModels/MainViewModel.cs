﻿using System.Windows.Input;

using Prism.Commands;

using VNC;
using VNC.Core.Mvvm;

using System;

namespace $safeprojectname$.Presentation.ViewModels
{
    public class MainViewModel : ViewModelBase
    {

        public MainViewModel()
        {
            Int64 startTicks = Log.CONSTRUCTOR("Enter", Common.LOG_APPNAME);

            Button1Command = new DelegateCommand(Button1Execute);
            Button2Command = new DelegateCommand(Button2Execute);
            Button3Command = new DelegateCommand(Button3Execute);

            Log.CONSTRUCTOR("Exit", Common.LOG_APPNAME, startTicks);
        }

        #region Fields and Properties



        private string _title = "$safeprojectname$ - MainWindow";

        public string Title
        {
            get => _title;
            set
            {
                if (_title == value)
                    return;
                _title = value;
                OnPropertyChanged();
            }
        }

        private string _message = "Initial Message";

        public string Message
        {
            get => _message;
            set
            {
                if (_message == value)
                    return;
                _message = value;
                OnPropertyChanged();
            }
        }

        private int _numerator = 10;
        public int Numerator
        {
            get => _numerator;
            set
            {
                if (_numerator == value)
                    return;
                _numerator = value;
                OnPropertyChanged();
            }
        }

        private int _denominator = 2;
        public int Denominator
        {
            get => _denominator;
            set
            {
                if (_denominator == value)
                    return;
                _denominator = value;
                OnPropertyChanged();
            }
        }
        
        private string _answer = "???";

        public string Answer
        {
            get => _answer;
            set
            {
                if (_answer == value)
                    return;
                _answer = value;
                OnPropertyChanged();
            }
        }

        public ICommand Button1Command { get; private set; }
        public ICommand Button2Command { get; private set; }
        public ICommand Button3Command { get; private set; }

        #endregion

        #region Private Methods

        private void Button1Execute()
        {
            Int64 startTicks = Log.Info("Enter", Common.LOG_APPNAME);

            Message = "Button1 Clicked";

            Log.Info("End", Common.LOG_APPNAME, startTicks);
        }

        private void Button2Execute()
        {
            Int64 startTicks = Log.Debug("Enter", Common.LOG_APPNAME);

            Message = "Button2 Clicked";

            Log.Debug("End", Common.LOG_APPNAME, startTicks);
        }

        private void Button3Execute()
        {
            Int64 startTicks = Log.Trace("Enter", Common.LOG_APPNAME);

            Message = "Button3 Clicked";

            try
            {
                method1();
            }
            catch (Exception ex)
            {
                Log.Error(ex, Common.LOG_APPNAME);
                Log.Error(ex, "BOOM");
            }

            Log.Trace("End", Common.LOG_APPNAME, startTicks);
        }

        private void method1()
        {
            Int64 startTicks = Log.Trace1("Enter", Common.LOG_APPNAME);

            method2();

            Log.Trace1("End", Common.LOG_APPNAME, startTicks);
        }

        private void method2()
        {
            Int64 startTicks = Log.Trace2("Enter", Common.LOG_APPNAME);

            method3();

            Log.Trace2("End", Common.LOG_APPNAME, startTicks);
        }

        private void method3()
        {
            Int64 startTicks = Log.Trace3("Enter", Common.LOG_APPNAME);

            method4();

            Log.Trace3("End", Common.LOG_APPNAME, startTicks);
        }

        private void method4()
        {
            Int64 startTicks = Log.Trace4("Enter", Common.LOG_APPNAME);

            method5();

            Log.Trace4("End", Common.LOG_APPNAME, startTicks);
        }

        private void method5()
        {
            Int64 startTicks = Log.Trace5("Enter", Common.LOG_APPNAME);

            // NOTE(crhodes)
            // Ha, Ha
            // Interpolated Strings swallowed the exception!

            //Answer = $"{Numerator / Denominator}";

            int answer = Numerator / Denominator;

            Answer = answer.ToString();

            Log.Trace5("End", Common.LOG_APPNAME, startTicks);
        }


        #endregion

    }
}
