﻿$safeprojectname$\Presentation\ViewModels\Interfaces\

Notes for using this template