﻿$safeprojectname$\Presentation\Views\Interfaces\

Notes for using this template