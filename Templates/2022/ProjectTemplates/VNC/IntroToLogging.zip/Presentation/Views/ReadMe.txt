﻿$safeprojectname$\Presentation\Views\

Notes for using this template