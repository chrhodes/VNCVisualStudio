﻿$safeprojectname$\Presentation\
$safeprojectname$\Presentation\Converters\
$safeprojectname$\Presentation\ModelWrappers\
$safeprojectname$\Presentation\ViewModels\
$safeprojectname$\Presentation\Views\

Notes for using this template